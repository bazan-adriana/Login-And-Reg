package com.adriana.loginandreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAndRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
